﻿namespace IndieXML
{


    public partial class CustomDataSet
    {
    }
}
